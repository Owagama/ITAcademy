/*
 Высокосным гододом (LeapYear) называют каждый четвертый год
 А так же каждый сотый год
 Кроме лет, которые делятся на 400

 Напишите функцию isLeapYear , которая возвращает является ли год высокосным.
 Проверьте, что тесты выполняются корректно
 */

struct Year {
    var year = 1900
    
    init(_ calendarYear: Int) {
        year = calendarYear
    }
}
    
    func isLeapYear (_ year: Int) -> Bool {
        if (year % 4 == 0 || year % 100 == 0) && year % 400 != 0 {
            print ("This Year is LeapYear")
            return true
    }
        print ("This Year is not LeapYear")
        return false
}

let correctYear = Year(1954)
var isBoolean = isLeapYear(correctYear.year)
