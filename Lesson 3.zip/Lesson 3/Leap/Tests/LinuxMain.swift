import XCTest
@testable import LeapTests

XCTMain([
    testCase(LeapTests.allTests),
    ])
