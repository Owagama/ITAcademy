//
//  ViewController.swift
//  memo
//
//  Created by Владислав Дашкевич on 28.03.2018.
//  Copyright © 2018 Владислав Дашкевич. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var cards: [UIButton]!
    var images = ["😀","😙","🤓","😀","😙","🤓", "🦉", "🦀"]
    var count = -1
    
    override func viewDidLoad() {
        /*
            for (i, card) in cards.enumerated(){
            card.setTitle(images[i], for: .normal)
        }
        */
    }
 
    
    @IBAction func cardTapped(_ sender: UIButton)
        {
            if sender.backgroundColor != UIColor.brown{
                count < 7 ? count += 1 : (count = 0)
                sender.setTitle(images[count], for: .normal)
                sender.backgroundColor = UIColor.brown
            } else {
                sender.setTitle("", for: .normal)
                sender.backgroundColor = UIColor.blue
            }
            
            
    }
}

